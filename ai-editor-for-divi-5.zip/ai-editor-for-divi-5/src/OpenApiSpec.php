<?php

declare(strict_types=1);

namespace AiEditorDivi5\WP;

if ( ! defined( 'ABSPATH' ) ) exit;

use WP_REST_Request;
use WP_REST_Response;

/**
 * Serves an OpenAPI 3.1 spec for the plugin REST endpoints.
 *
 * Used by ChatGPT Actions and any OpenAPI-compatible client.
 * Endpoint: GET /wp-json/ai-editor-divi5/v1/openapi.json
 */
final class OpenApiSpec
{
    public function register_routes(): void
    {
        register_rest_route('ai-editor-divi5/v1', '/openapi.json', [
            'methods'             => 'GET',
            'callback'            => [$this, 'serve'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function serve(WP_REST_Request $request): WP_REST_Response
    {
        $base = rtrim(get_site_url(), '/') . '/wp-json/ai-editor-divi5/v1';
        return new WP_REST_Response(self::spec($base, AI_EDITOR_DIVI5_VERSION), 200);
    }

    /**
     * Builds the OpenAPI 3.1 spec array. Pure (base + version injected) so it is
     * unit-testable — notably that every operation description stays within
     * ChatGPT Actions' 300-character limit and no response object schema is empty
     * (ChatGPT rejects a bare `type: object` with no properties).
     *
     * @return array<string, mixed>
     */
    public static function spec(string $base, string $version): array
    {
        return [
            'openapi' => '3.1.0',
            'info'    => [
                'title'       => 'AI Editor for Divi 5',
                'description' => 'Let your AI assistant read and edit Divi 5 pages with natural language. Every change is validated before saving — broken pages become impossible.',
                'version'     => $version,
            ],
            'servers'    => [['url' => $base]],
            'security'   => [['ApiKey' => []]],
            'components' => [
                'securitySchemes' => [
                    'ApiKey' => [
                        'type'        => 'http',
                        'scheme'      => 'bearer',
                        'description' => 'Plugin API key from Settings → AI Editor for Divi 5',
                    ],
                ],
                'schemas' => [
                    'Violation' => [
                        'type'       => 'object',
                        'properties' => [
                            'code'    => ['type' => 'string', 'description' => 'Machine-readable violation code'],
                            'message' => ['type' => 'string', 'description' => 'Human-readable description'],
                            'path'    => ['type' => 'string', 'description' => 'Path to the offending block'],
                        ],
                    ],
                    'PageSummary' => [
                        'type'       => 'object',
                        'properties' => [
                            'id'        => ['type' => 'integer'],
                            'title'     => ['type' => 'string'],
                            'status'    => ['type' => 'string'],
                            'link'      => ['type' => 'string'],
                            'edit_link' => ['type' => 'string'],
                        ],
                    ],
                    'ValidationResult' => [
                        'type'       => 'object',
                        'properties' => [
                            'valid'      => ['type' => 'boolean'],
                            'violations' => ['type' => 'array', 'items' => ['$ref' => '#/components/schemas/Violation']],
                        ],
                    ],
                    'HistoryEntry' => [
                        'type'       => 'object',
                        'properties' => [
                            'id'       => ['type' => 'integer', 'description' => 'Version id (use with restore)'],
                            'saved_at' => ['type' => 'string',  'description' => 'UTC time the snapshot was taken'],
                            'tool'     => ['type' => 'string',  'description' => 'Which action replaced this version'],
                            'actor'    => ['type' => 'integer', 'description' => 'WordPress user id'],
                            'bytes'    => ['type' => 'integer'],
                            'label'    => ['type' => 'string'],
                        ],
                    ],
                    'SnapshotInfo' => [
                        'type'       => 'object',
                        'properties' => [
                            'stored'     => ['type' => 'boolean', 'description' => 'True if the previous content was saved as an undo version'],
                            'version_id' => ['type' => 'integer', 'description' => 'Version id to pass to restorePageVersion (when stored)'],
                            'reason'     => ['type' => 'string',  'description' => 'Why nothing was stored: duplicate, too_large, invalid_encoding or store_failed (absent or null when stored)'],
                        ],
                    ],
                ],
            ],
            'paths' => [
                '/pages' => [
                    'get' => [
                        'operationId' => 'listDiviPages',
                        'summary'     => 'List all Divi 5 pages',
                        'description' => 'Returns all WordPress pages that use the Divi 5 builder, including their IDs and edit links.',
                        'responses'   => [
                            '200' => [
                                'description' => 'Success',
                                'content'     => ['application/json' => ['schema' => [
                                    'type'       => 'object',
                                    'properties' => [
                                        'pages' => ['type' => 'array', 'items' => ['$ref' => '#/components/schemas/PageSummary']],
                                        'count' => ['type' => 'integer'],
                                    ],
                                ]]],
                            ],
                        ],
                    ],
                    'post' => [
                        'operationId' => 'createPage',
                        'summary'     => 'Create a new page (premium)',
                        'description' => 'PREMIUM: Validates the submitted layout and, if valid, creates a new page as a draft for the owner to review and publish. Returns 402 if there is no active license, or 422 with violations if the layout is invalid — no page is created in either case.',
                        'requestBody' => [
                            'required' => true,
                            'content'  => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'required'   => ['title', 'post_content'],
                                'properties' => [
                                    'title'        => ['type' => 'string', 'description' => 'Page title'],
                                    'post_content' => ['type' => 'string', 'description' => 'Divi 5 Gutenberg block HTML'],
                                    'slug'         => ['type' => 'string', 'description' => 'Optional URL slug for cross-linking'],
                                ],
                            ]]],
                        ],
                        'responses'   => [
                            '201' => ['description' => 'Page created'],
                            '400' => ['description' => 'Missing title or post_content'],
                            '402' => ['description' => 'Premium license required'],
                            '422' => ['description' => 'Validation failed', 'content' => ['application/json' => ['schema' => ['$ref' => '#/components/schemas/ValidationResult']]]],
                        ],
                    ],
                ],
                '/pages/{id}' => [
                    'get' => [
                        'operationId' => 'getPageLayout',
                        'summary'     => 'Get a page layout',
                        'description' => 'Returns the full Divi 5 post_content (Gutenberg block HTML) and metadata for a page.',
                        'parameters'  => [self::idParam()],
                        'responses'   => [
                            '200' => ['description' => 'Page layout', 'content' => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'properties' => [
                                    'post_id'      => ['type' => 'integer'],
                                    'post_title'   => ['type' => 'string'],
                                    'post_status'  => ['type' => 'string'],
                                    'post_content' => ['type' => 'string', 'description' => 'Divi 5 Gutenberg block HTML'],
                                    'format'       => ['type' => 'string'],
                                    'divi_version' => ['type' => 'string'],
                                ],
                                'additionalProperties' => true,
                            ]]]],
                            '404' => ['description' => 'Page not found'],
                        ],
                    ],
                    'put' => [
                        'operationId' => 'updatePageLayout',
                        'summary'     => 'Validate and save a page layout',
                        'description' => 'Validates the submitted layout and saves it only if all checks pass. Returns 422 with violations if the layout is invalid — the page is NOT updated.',
                        'parameters'  => [self::idParam()],
                        'requestBody' => self::postContentBody(),
                        'responses'   => [
                            '200' => ['description' => 'Layout saved; history reports the undo snapshot', 'content' => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'properties' => [
                                    'saved'      => ['type' => 'boolean'],
                                    'valid'      => ['type' => 'boolean'],
                                    'history'    => ['$ref' => '#/components/schemas/SnapshotInfo'],
                                ],
                                'additionalProperties' => true,
                            ]]]],
                            '400' => ['description' => 'Missing post_content'],
                            '404' => ['description' => 'Page not found'],
                            '422' => ['description' => 'Validation failed', 'content' => ['application/json' => ['schema' => ['$ref' => '#/components/schemas/ValidationResult']]]],
                        ],
                    ],
                ],
                '/pages/{id}/edit' => [
                    'post' => [
                        'operationId' => 'editPageContent',
                        'summary'     => 'Surgically edit page text (find/replace)',
                        'description' => 'Change one small part of a page by exact find-and-replace, without resending the whole layout (e.g. an email, phone, link, or line of copy). "find" must match once unless expect_count is set. Returns 422 and leaves the page unchanged if find is missing, ambiguous, or would break validation.',
                        'parameters'  => [self::idParam()],
                        'requestBody' => [
                            'required' => true,
                            'content'  => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'required'   => ['find', 'replace'],
                                'properties' => [
                                    'find'         => ['type' => 'string',  'description' => 'Exact text to find (verbatim; include surrounding text so it is unique)'],
                                    'replace'      => ['type' => 'string',  'description' => 'Text to replace it with'],
                                    'expect_count' => ['type' => 'integer', 'description' => 'Optional: number of matches to replace (must equal the number found)'],
                                ],
                            ]]],
                        ],
                        'responses'   => [
                            '200' => ['description' => 'Edit saved; history reports the undo snapshot', 'content' => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'properties' => [
                                    'saved'      => ['type' => 'boolean'],
                                    'replaced'   => ['type' => 'integer'],
                                    'history'    => ['$ref' => '#/components/schemas/SnapshotInfo'],
                                ],
                                'additionalProperties' => true,
                            ]]]],
                            '400' => ['description' => 'Missing find or replace'],
                            '404' => ['description' => 'Page not found'],
                            '422' => ['description' => 'Find not found, ambiguous, or edit would invalidate — page unchanged', 'content' => ['application/json' => ['schema' => ['$ref' => '#/components/schemas/ValidationResult']]]],
                        ],
                    ],
                ],
                '/pages/{id}/history' => [
                    'get' => [
                        'operationId' => 'listPageHistory',
                        'summary'     => 'List a page\'s saved previous versions',
                        'description' => 'Every AI save tries to snapshot the page\'s prior content (last 10, fewer for large pages). Returns saved versions newest first (id, time, tool, size); restore one with restorePageVersion when a snapshot was kept (history.stored).',
                        'parameters'  => [self::idParam()],
                        'responses'   => [
                            '200' => ['description' => 'Versions', 'content' => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'properties' => [
                                    'page_id'  => ['type' => 'integer'],
                                    'count'    => ['type' => 'integer'],
                                    'versions' => ['type' => 'array', 'items' => ['$ref' => '#/components/schemas/HistoryEntry']],
                                ],
                            ]]]],
                            '404' => ['description' => 'Page not found'],
                        ],
                    ],
                ],
                '/pages/{id}/history/{versionId}' => [
                    'get' => [
                        'operationId' => 'getPageHistoryEntry',
                        'summary'     => 'Get one saved version\'s content',
                        'description' => 'Returns the full saved content of one previous version (from listPageHistory), e.g. to compare it with the current layout before restoring.',
                        'parameters'  => [self::idParam(), self::versionParam()],
                        'responses'   => [
                            '200' => ['description' => 'Version content', 'content' => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'properties' => [
                                    'page_id'      => ['type' => 'integer'],
                                    'version'      => ['$ref' => '#/components/schemas/HistoryEntry'],
                                    'post_content' => ['type' => 'string', 'description' => 'Divi 5 Gutenberg block HTML'],
                                ],
                            ]]]],
                            '404' => ['description' => 'Page or version not found'],
                        ],
                    ],
                ],
                '/pages/{id}/restore' => [
                    'post' => [
                        'operationId' => 'restorePageVersion',
                        'summary'     => 'Undo: restore a saved version',
                        'description' => 'Restores a page to a previous saved version. The current content is snapshotted first; the restore is itself undoable when its own history.stored is true. Not blocked by validation (it is the owner\'s own earlier content); the response reports whether it passes the validator.',
                        'parameters'  => [self::idParam()],
                        'requestBody' => [
                            'required' => true,
                            'content'  => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'required'   => ['version_id'],
                                'properties' => ['version_id' => ['type' => 'integer', 'description' => 'Version id from listPageHistory']],
                            ]]],
                        ],
                        'responses'   => [
                            '200' => ['description' => 'Restored', 'content' => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'properties' => [
                                    'restored'         => ['type' => 'boolean'],
                                    'restored_version' => ['type' => 'integer'],
                                    'history'          => ['$ref' => '#/components/schemas/SnapshotInfo'],
                                    'validator'        => ['$ref' => '#/components/schemas/ValidationResult'],
                                ],
                            ]]]],
                            '400' => ['description' => 'Missing version_id'],
                            '404' => ['description' => 'Page or version not found'],
                        ],
                    ],
                ],
                '/style-guide' => [
                    'get' => [
                        'operationId' => 'getStyleGuide',
                        'summary'     => 'Get the Divi 5 authoring + styling guide',
                        'description' => 'Returns real block structure rules, required content keys, and styling attribute shapes (backgrounds, gradients, spacing, typography, borders, shadows, transforms, hover, animation). Call before building or restyling a layout so the result is styled, not plain.',
                        'responses'   => [
                            '200' => ['description' => 'The guide (Markdown)', 'content' => ['application/json' => ['schema' => ['type' => 'object', 'properties' => ['guide' => ['type' => 'string']]]]]],
                        ],
                    ],
                ],
                '/site-guide' => [
                    'get' => [
                        'operationId' => 'getSiteGuide',
                        'summary'     => 'Get the multi-page site blueprint',
                        'description' => 'Blueprint for building an entire multi-page website from one brief: plan pages, lock one design system, build each page with a slug, cross-link, then set the front page and nav menu.',
                        'responses'   => ['200' => ['description' => 'The blueprint (Markdown)', 'content' => ['application/json' => ['schema' => ['type' => 'object', 'properties' => ['guide' => ['type' => 'string']]]]]]],
                    ],
                ],
                '/landing-guide' => [
                    'get' => [
                        'operationId' => 'getLandingGuide',
                        'summary'     => 'Get the conversion-focused landing page blueprint',
                        'description' => 'Strategic blueprint for a landing page that converts: the persuasion flow (hero, problem, solution, benefits, social proof, features, FAQ, final CTA), how to adapt it to the business and audience, plus copywriting and CTA-placement rules. Call before building a marketing page.',
                        'responses'   => ['200' => ['description' => 'The blueprint (Markdown)', 'content' => ['application/json' => ['schema' => ['type' => 'object', 'properties' => ['guide' => ['type' => 'string']]]]]]],
                    ],
                ],
                '/image-guide' => [
                    'get' => [
                        'operationId' => 'getImageGuide',
                        'summary'     => 'Get the image-intelligence guide',
                        'description' => 'How to assign the right visual to each section by role using keyless sources (LoremFlickr, Picsum, Random User and Pravatar avatars, Placehold.co). Covers per-section rules, keyword derivation, stable pinning, and sizing. Call before choosing any image src.',
                        'responses'   => ['200' => ['description' => 'The guide (Markdown)', 'content' => ['application/json' => ['schema' => ['type' => 'object', 'properties' => ['guide' => ['type' => 'string']]]]]]],
                    ],
                ],
                '/front-page' => [
                    'post' => [
                        'operationId' => 'setFrontPage',
                        'summary'     => 'Set the static front page (premium)',
                        'description' => 'PREMIUM: Make a page the site front page.',
                        'requestBody' => ['required' => true, 'content' => ['application/json' => ['schema' => ['type' => 'object', 'required' => ['page_id'], 'properties' => ['page_id' => ['type' => 'integer']]]]]],
                        'responses'   => ['200' => ['description' => 'Front page set'], '402' => ['description' => 'Premium required'], '404' => ['description' => 'Page not found']],
                    ],
                ],
                '/primary-menu' => [
                    'post' => [
                        'operationId' => 'setPrimaryMenu',
                        'summary'     => 'Build + assign the primary nav menu (premium)',
                        'description' => 'PREMIUM: Build the Main Menu from items and assign it to the theme primary location.',
                        'requestBody' => ['required' => true, 'content' => ['application/json' => ['schema' => ['type' => 'object', 'required' => ['items'], 'properties' => ['items' => ['type' => 'array', 'items' => ['type' => 'object', 'properties' => ['title' => ['type' => 'string'], 'page_id' => ['type' => 'integer'], 'url' => ['type' => 'string']]]]]]]]],
                        'responses'   => ['200' => ['description' => 'Menu built'], '402' => ['description' => 'Premium required']],
                    ],
                ],
                '/section-recipes' => [
                    'get' => [
                        'operationId' => 'getSectionRecipes',
                        'summary'     => 'Get proven section recipes',
                        'description' => 'Library of complete, validated Divi 5 section patterns (hero, feature grids, split, slider, CTA, footer). With no query, returns the catalog of recipe names; pass ?name=<recipe> to get that section\'s full block markup to copy and fill.',
                        'parameters'  => [['name' => 'name', 'in' => 'query', 'required' => false, 'schema' => ['type' => 'string', 'description' => 'Recipe name (omit to list all)']]],
                        'responses'   => [
                            '200' => ['description' => 'Catalog or a single recipe', 'content' => ['application/json' => ['schema' => [
                                'type'       => 'object',
                                'properties' => [
                                    'catalog' => ['type' => 'object', 'additionalProperties' => true, 'description' => 'Recipe names to summaries (when listing)'],
                                    'names'   => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'All recipe names (when listing)'],
                                    'name'    => ['type' => 'string', 'description' => 'The requested recipe name (single lookup)'],
                                    'markup'  => ['type' => 'string', 'description' => 'Block markup for the requested recipe'],
                                ],
                                'additionalProperties' => true,
                            ]]]],
                            '404' => ['description' => 'Unknown recipe name'],
                        ],
                    ],
                ],
                '/validate' => [
                    'post' => [
                        'operationId' => 'validateLayout',
                        'summary'     => 'Validate a layout without saving',
                        'description' => 'Runs all validation passes on a Divi 5 post_content string without writing to the database. Safe to call repeatedly.',
                        'requestBody' => self::postContentBody(),
                        'responses'   => [
                            '200' => ['description' => 'Valid layout',   'content' => ['application/json' => ['schema' => ['$ref' => '#/components/schemas/ValidationResult']]]],
                            '422' => ['description' => 'Invalid layout', 'content' => ['application/json' => ['schema' => ['$ref' => '#/components/schemas/ValidationResult']]]],
                        ],
                    ],
                ],
            ],
        ];
    }

    private static function idParam(): array
    {
        return ['name' => 'id', 'in' => 'path', 'required' => true, 'schema' => ['type' => 'integer', 'description' => 'WordPress page ID']];
    }

    private static function versionParam(): array
    {
        return ['name' => 'versionId', 'in' => 'path', 'required' => true, 'schema' => ['type' => 'integer', 'description' => 'Version id from listPageHistory']];
    }

    private static function postContentBody(): array
    {
        return [
            'required' => true,
            'content'  => ['application/json' => ['schema' => [
                'type'       => 'object',
                'required'   => ['post_content'],
                'properties' => ['post_content' => ['type' => 'string', 'description' => 'Divi 5 Gutenberg block HTML']],
            ]]],
        ];
    }
}
