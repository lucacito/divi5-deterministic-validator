<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) exit;

// Wrap in a closure to avoid polluting global scope with loader variables.
(function () {
    $validator_src = __DIR__ . '/../validator';
    foreach ( ['Violation', 'ValidationResult', 'SchemaRules', 'Block', 'ParseResult', 'BlockParser', 'Validator'] as $cls ) {
        require_once $validator_src . '/' . $cls . '.php';
    }
})();

// Load plugin classes
require_once __DIR__ . '/ApiKey.php';
require_once __DIR__ . '/Licensing/LicenseClient.php';
require_once __DIR__ . '/Licensing.php';
require_once __DIR__ . '/StyleGuide.php';
require_once __DIR__ . '/SectionRecipes.php';
require_once __DIR__ . '/SiteGuide.php';
require_once __DIR__ . '/LandingGuide.php';
require_once __DIR__ . '/ImageGuide.php';
require_once __DIR__ . '/MenuBuilder.php';
require_once __DIR__ . '/PhpProposals.php';
require_once __DIR__ . '/CustomCss.php';
require_once __DIR__ . '/UsageTracker.php';
require_once __DIR__ . '/PageEditor.php';
require_once __DIR__ . '/RestController.php';
require_once __DIR__ . '/McpHandler.php';
require_once __DIR__ . '/OpenApiSpec.php';
require_once __DIR__ . '/AdminPage.php';
