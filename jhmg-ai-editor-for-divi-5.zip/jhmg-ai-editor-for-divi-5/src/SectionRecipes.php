<?php

declare(strict_types=1);

namespace AiEditorDivi5\WP;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once __DIR__ . '/DesignLanguages.php';
require_once __DIR__ . '/RecipeTokens.php';
require_once __DIR__ . '/StyleKits.php';
require_once __DIR__ . '/KitResolver.php';
require_once __DIR__ . '/KitAdapters.php';
require_once __DIR__ . '/BlockAttrs.php';
require_once __DIR__ . '/LanguageAdapters.php';
require_once __DIR__ . '/LanguageResolver.php';

/**
 * Library of real, validated Divi 5 section recipes — whole proven sections the
 * AI copies and fills with the user's content, instead of composing from
 * primitives. Each recipe is a section block fragment extracted verbatim from a
 * real export (local image URLs swapped for local image tokens, resolved at serve time to
 * the plugin's bundled image pack).
 *
 * Served by the get_section_recipes tool: no name => the catalog (small);
 * a name => that recipe's full block markup.
 */
final class SectionRecipes
{
    private const DATA = __DIR__ . '/../data/section-recipes.json';

    /** What a recipe is for (controlled vocabulary of the `role` tag). */
    public const ROLES = [ 'hero', 'proof', 'features', 'stats', 'testimonials', 'pricing', 'team', 'faq', 'process', 'cta', 'gallery', 'contact', 'header', 'transition', 'content', 'shop', 'blog' ];

    /** How a recipe is arranged (controlled vocabulary of the `layout` tag). */
    public const LAYOUTS = [ 'centered', 'split', 'grid', 'bento', 'zigzag', 'stacked', 'carousel', 'overlap', 'band', 'list', 'form' ];

    /**
     * Mood words a recipe can carry (the `mood` tag is a list of these). 'any' fits every design.
     *
     * @return list<string>
     */
    public static function moods(): array
    {
        return [ 'any', ...DesignLanguages::ids() ];
    }

    /** @var ?list<array{name:string,title:string,description:string,when:string,stage:string,tags?:array<string,mixed>,markup:string}> the decoded recipes, read once per request */
    private static ?array $cache = null;

    /** What a mood value is (one sentence, shared by the catalog, the MCP tool and the OpenAPI parameter). */
    public const MOOD_HELP = 'Moods are design language ids (get_style_guide topic=design-languages); "any" lists only recipes that suit every look.';

    /**
     * What the optional style_kit parameter is (one sentence, shared by the MCP tool and the OpenAPI parameter).
     */
    public static function styleKitHelp(): string
    {
        // Names no kit id on purpose: the text stays the same however many kits ship (the ids are in the style-kits topic).
        return 'With name: serve the recipe\'s buttons, cards, accordions and toggles in this style kit instead of the design language\'s own kit; get_style_guide topic style-kits lists the kits, and an unknown id is refused with the list of valid ids.';
    }

    /** Forgets the memoised recipes (for tests that change the data in-process). */
    public static function clearCache(): void
    {
        self::$cache = null;
    }

    /** @return list<array{name:string,title:string,description:string,when:string,stage:string,tags?:array<string,mixed>,markup:string}> */
    private static function all(): array
    {
        if ( null === self::$cache ) {
            $raw         = is_readable( self::DATA ) ? (string) file_get_contents( self::DATA ) : '';
            $data        = json_decode( $raw, true );
            self::$cache = is_array( $data ) ? $data : [];
        }
        return self::$cache;
    }

    /**
     * Markdown catalog.
     *
     * No filters: a compact list (recipe names under role headings, a few words each) plus how to
     * fetch one. With a role, layout and/or mood filter: the full one-line description of the
     * matching recipes only. An unknown filter value, or a filter nothing matches, returns a
     * message that lists the valid values.
     */
    public static function catalog( ?string $role = null, ?string $layout = null, ?string $mood = null ): string
    {
        $role   = self::cleanFilter( $role );
        $layout = self::cleanFilter( $layout );
        $mood   = self::cleanFilter( $mood );

        if ( null === $role && null === $layout && null === $mood ) {
            return self::compactCatalog();
        }

        $problems = [];
        if ( null !== $role && ! in_array( $role, self::ROLES, true ) ) {
            $problems[] = sprintf( 'Unknown role "%s". Valid roles: %s.', $role, implode( ', ', self::ROLES ) );
        }
        if ( null !== $layout && ! in_array( $layout, self::LAYOUTS, true ) ) {
            $problems[] = sprintf( 'Unknown layout "%s". Valid layouts: %s.', $layout, implode( ', ', self::LAYOUTS ) );
        }
        if ( null !== $mood && ! in_array( $mood, self::moods(), true ) ) {
            $problems[] = sprintf( 'Unknown mood "%s". Valid moods: %s.', $mood, implode( ', ', self::moods() ) );
        }
        if ( $problems ) {
            return implode( "\n", $problems );
        }

        $lines = [];
        foreach ( self::matchingRows( $role, $layout, $mood ) as $r ) {
            $stage   = isset( $r['stage'] ) ? (string) $r['stage'] : 'Supporting';
            $lines[] = sprintf( '- **%s** — %s _Stage:_ %s. _When:_ %s', $r['name'], $r['description'], $stage, $r['when'] );
        }

        $applied = [];
        foreach ( [ 'role' => $role, 'layout' => $layout, 'mood' => $mood ] as $k => $v ) {
            if ( null !== $v ) {
                $applied[] = $k . '=' . $v;
            }
        }
        if ( ! $lines && null !== $mood ) {
            // The mood alone emptied a role/layout that has recipes: say so, it is not a wrong value.
            $others = self::matchingNames( $role, $layout, null );
            if ( [] !== $others && ( null !== $role || null !== $layout ) ) {
                $without = [];
                foreach ( [ 'role' => $role, 'layout' => $layout ] as $k => $v ) {
                    if ( null !== $v ) {
                        $without[] = $k . '=' . $v;
                    }
                }
                return sprintf(
                    'No recipe matches %s. %d recipe%s %s %s under other moods; call again without mood, then fetch the recipe with design_language=%s (the tokens re-skin any recipe in any language, every colour pair is AA in all ten).',
                    implode( ', ', $applied ),
                    count( $others ),
                    1 === count( $others ) ? '' : 's',
                    1 === count( $others ) ? 'has' : 'have',
                    implode( ', ', $without ),
                    'any' === $mood ? '<id>' : $mood
                );
            }
        }
        if ( ! $lines ) {
            return sprintf(
                "No recipe matches %s.\nValid roles: %s.\nValid layouts: %s.\nValid moods: %s.\nRoles that have recipes: %s.",
                implode( ', ', $applied ),
                implode( ', ', self::ROLES ),
                implode( ', ', self::LAYOUTS ),
                implode( ', ', self::moods() ),
                implode( ', ', self::rolesInUse() )
            );
        }
        return implode( "\n", array_merge(
            [
                '# Divi 5 Section Recipes (' . implode( ', ', $applied ) . ')',
                '',
                'Fetch one with get_section_recipes {"name":"<name>"}.',
                '',
            ],
            $lines
        ) );
    }

    /**
     * Names of the recipes the role, layout and mood filters select, in catalog order. An unknown
     * value matches nothing (catalog() explains it); no filter at all matches every recipe.
     *
     * @return list<string>
     */
    public static function matchingNames( ?string $role = null, ?string $layout = null, ?string $mood = null ): array
    {
        $role   = self::cleanFilter( $role );
        $layout = self::cleanFilter( $layout );
        $mood   = self::cleanFilter( $mood );
        if (
            ( null !== $role && ! in_array( $role, self::ROLES, true ) )
            || ( null !== $layout && ! in_array( $layout, self::LAYOUTS, true ) )
            || ( null !== $mood && ! in_array( $mood, self::moods(), true ) )
        ) {
            return [];
        }

        return array_map( static fn ( array $r ): string => $r['name'], self::matchingRows( $role, $layout, $mood ) );
    }

    /**
     * @param string|null $role   already cleaned
     * @param string|null $layout already cleaned
     * @param string|null $mood   already cleaned
     * @return list<array{name:string,title:string,description:string,when:string,stage:string,tags?:array<string,mixed>,markup:string}>
     */
    private static function matchingRows( ?string $role, ?string $layout, ?string $mood ): array
    {
        $rows = [];
        foreach ( self::all() as $r ) {
            $tags = isset( $r['tags'] ) && is_array( $r['tags'] ) ? $r['tags'] : [];
            if ( null !== $role && ( $tags['role'] ?? null ) !== $role ) {
                continue;
            }
            if ( null !== $layout && ( $tags['layout'] ?? null ) !== $layout ) {
                continue;
            }
            if ( null !== $mood ) {
                $moods = isset( $tags['mood'] ) && is_array( $tags['mood'] ) ? $tags['mood'] : [];
                if ( ! in_array( $mood, $moods, true ) && ! in_array( 'any', $moods, true ) ) {
                    continue;
                }
            }
            $rows[] = $r;
        }
        return $rows;
    }

    /**
     * Make a caller-supplied string safe to quote back in an answer the AI reads: trim, keep only plain
     * characters (letters, digits, space, _ . : -; no newline, quote, backtick or Markdown syntax) and cut it
     * to 40 characters. Every "Unknown ..." message that echoes input goes through this.
     */
    public static function plain( string $value, string $strip = '/[^A-Za-z0-9 _.:-]/' ): string
    {
        return substr( (string) preg_replace( $strip, '', trim( $value ) ), 0, 40 );
    }

    /** Trim and lower-case a filter value, keeping it short and plain; empty means no filter. */
    private static function cleanFilter( ?string $value ): ?string
    {
        if ( null === $value ) {
            return null;
        }
        $value = self::plain( strtolower( $value ), '/[^a-z0-9 _-]/' );
        return '' === $value ? null : $value;
    }

    /** @return list<string> roles that at least one recipe carries, in ROLES order */
    private static function rolesInUse(): array
    {
        $used = [];
        foreach ( self::all() as $r ) {
            $used[ (string) ( $r['tags']['role'] ?? '' ) ] = true;
        }
        return array_values( array_filter( self::ROLES, static fn ( string $role ): bool => isset( $used[ $role ] ) ) );
    }

    /** The default catalog: names under role headings, a few words each, and how to fetch one. */
    private static function compactCatalog(): string
    {
        $lines = [
            '# Divi 5 Section Recipes',
            '',
            'Whole proven, validated sections. Pick the recipes you need, fetch each with',
            'get_section_recipes {"name":"<name>"}, replace the example text with the user\'s content and',
            'swap the example images for Media Library images (list_media_images) when suitable ones exist.',
            'Place sections between the root <!-- wp:divi/placeholder --> ... <!-- /wp:divi/placeholder --> wrapper.',
            'Filter with get_section_recipes {"role":"hero"}, {"layout":"split"} or {"mood":"editorial"}: that lists',
            'only the matches, each with its full description, _Stage:_ and _When:_. ' . self::MOOD_HELP,
            'get_section_recipes accepts an optional design_language (ids from get_style_guide topic design-languages),',
            'used together with name: it fills that recipe\'s colours and fonts; a listing or no design_language gives the default look.',
            '',
            'The preset and color ids inside the recipe markup come from a demo site and may not exist',
            'on this site. Call list_global_styles and swap them for this site\'s own ids, or remove the',
            '"modulePreset" attribute (a module without one gets this site\'s default preset).',
            '',
            'Bracketed texts, demo counter values and image alt texts are placeholders: replace each with the owner\'s',
            'real content or remove it; never keep an invented fact.',
            '',
            'Persuasion stages the recipes serve (flow in get_landing_guide): Hero, Problem, Solution, Benefits,',
            'Social proof, How it works, Pricing, FAQ, Final CTA, Contact, Resources. Pick a recipe per stage.',
        ];

        $byRole = [];
        foreach ( self::all() as $r ) {
            $role              = (string) ( $r['tags']['role'] ?? 'content' );
            $layout            = (string) ( $r['tags']['layout'] ?? '' );
            $byRole[ $role ][] = sprintf( '- %s — %s%s', $r['name'], $r['title'], '' !== $layout ? ' (' . $layout . ')' : '' );
        }
        foreach ( self::ROLES as $role ) {
            if ( isset( $byRole[ $role ] ) ) {
                $lines[] = '';
                $lines[] = '## ' . $role;
                array_push( $lines, ...$byRole[ $role ] );
            }
        }
        return implode( "\n", $lines );
    }

    /**
     * The tags of one recipe (role, layout, mood, density, background, needs_images), or null
     * when the name is unknown or the recipe carries none.
     *
     * @return array<string,mixed>|null
     */
    public static function tags( string $name ): ?array
    {
        foreach ( self::all() as $r ) {
            if ( $r['name'] === $name ) {
                return isset( $r['tags'] ) && is_array( $r['tags'] ) ? $r['tags'] : null;
            }
        }
        return null;
    }

    /**
     * Names of recipes whose layout and role are not in the avoid lists, in catalog order
     * (deterministic), at most $limit. $onlyRoles and $onlyBackgrounds, when not empty, keep only recipes whose role /
     * background tag is in the list (an empty list means no restriction).
     *
     * @param list<string> $avoidLayouts
     * @param list<string> $avoidRoles
     * @param list<string> $onlyRoles
     * @param list<string> $onlyBackgrounds
     * @return list<string>
     */
    public static function suggest( array $avoidLayouts, array $avoidRoles, int $limit = 3, array $onlyRoles = [], array $onlyBackgrounds = [] ): array
    {
        $out = [];
        foreach ( self::all() as $r ) {
            if ( count( $out ) >= $limit ) {
                break;
            }
            $tags = isset( $r['tags'] ) && is_array( $r['tags'] ) ? $r['tags'] : null;
            if ( null === $tags || in_array( $tags['layout'] ?? null, $avoidLayouts, true ) || in_array( $tags['role'] ?? null, $avoidRoles, true ) ) {
                continue;
            }
            if ( ( [] !== $onlyRoles && ! in_array( $tags['role'] ?? null, $onlyRoles, true ) )
                || ( [] !== $onlyBackgrounds && ! in_array( $tags['background'] ?? null, $onlyBackgrounds, true ) ) ) {
                continue;
            }
            $out[] = $r['name'];
        }
        return $out;
    }

    /**
     * Full block markup for one recipe, or null if the name is unknown, the design language id is, or
     * the style kit id is.
     *
     * The style kit is $kit when given, otherwise the language's own `kit` (the default language,
     * editorial, when no language is requested). Four steps, in this order: image tokens (ImageTokens),
     * the language's markers (LanguageResolver: type on headings and labels, rhythm on sections), the kit's markers and whole-value kit tokens
     * (KitResolver), then colour and font tokens with the language (RecipeTokens); the last three are
     * resolveMarkup(). The markup handed out never contains a token or a marker: an unknown or invalid
     * kit, kit data that cannot be read, or a marker the language or the kit cannot resolve returns
     * null, never partially resolved markup.
     */
    public static function recipe(string $name, ?string $language = null, ?string $kit = null): ?string
    {
        $lang = null === $language ? RecipeTokens::default() : DesignLanguages::get($language);
        if (null === $lang) {
            return null;
        }
        $kitId = $kit ?? (is_string($lang['kit'] ?? null) ? $lang['kit'] : null);
        $styleKit = null === $kitId ? null : StyleKits::get($kitId);
        if (null === $styleKit || [] !== StyleKits::problems($styleKit)) {
            return null;
        }
        foreach ( self::all() as $r ) {
            if ( $r['name'] === $name ) {
                $markup = ImageTokens::resolve(
                    $r['markup'],
                    self::imageBaseUrl(),
                    null,
                    static fn ( ?string $u, string $t ): ?string => apply_filters( 'jhmg_aied_image_token', $u, $t )
                );
                return self::resolveMarkup( $markup, $lang, $styleKit );
            }
        }
        return null;
    }

    /**
     * The serve-time pipeline after the image step, the one place it is spelled: the language's markers
     * (LanguageResolver), then the kit's markers and whole-value kit tokens (KitResolver), then colour and
     * font tokens (RecipeTokens). Null when the language step leaves a language marker (so a type or rhythm
     * marker never reaches the kit step) or the kit step leaves anything (KitResolver::leftovers()).
     *
     * @param array<string,mixed> $language
     * @param array<string,mixed> $kit
     */
    public static function resolveMarkup( string $markup, array $language, array $kit ): ?string
    {
        $markup = LanguageResolver::resolve( $markup, $language );
        if ( [] !== LanguageResolver::leftovers( $markup ) ) {
            return null;
        }
        $markup = RecipeTokens::resolve( KitResolver::resolve( $markup, $kit ), $language );

        return [] === KitResolver::leftovers( $markup ) ? $markup : null;
    }

    /** The stored markup of one recipe with image tokens left unresolved (dev tooling and tests), or null. */
    public static function rawMarkup(string $name): ?string
    {
        foreach ( self::all() as $r ) {
            if ( $r['name'] === $name ) {
                return (string) $r['markup'];
            }
        }
        return null;
    }

    /** Site-local URL of the bundled image pack directory ('' outside WordPress). */
    private static function imageBaseUrl(): string
    {
        return defined( 'AI_EDITOR_DIVI5_FILE' ) ? plugins_url( 'assets/images/', AI_EDITOR_DIVI5_FILE ) : '';
    }

    /** Number of recipes in the library (the readme states it; tests check it). */
    public static function count(): int
    {
        return count( self::all() );
    }

    /** @return list<string> recipe names (used by tests) */
    public static function names(): array
    {
        return array_map( static fn( array $r ): string => $r['name'], self::all() );
    }
}
