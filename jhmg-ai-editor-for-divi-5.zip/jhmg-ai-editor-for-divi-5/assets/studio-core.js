/* JHMG AI Editor for Divi 5: Lab, the pure part.
 *
 * Functions with no DOM and no requests: building the brief from the form state, merging words an assistant wrote,
 * moving sections, the item-count guard and the layout swap (the same rule as StudioMerge::swapRecipe on the server:
 * a value moves only to a slot with the same id AND role AND kind). studio.js uses them in the browser;
 * scripts/test-studio-ui.cjs tests them with node. Nothing here builds HTML.
 */
(function (root, factory) {
    'use strict';
    if (typeof module === 'object' && module.exports) {
        module.exports = factory();
    } else {
        root.aiedLabCore = factory();
    }
}(this, function () {
    'use strict';

    var own = function (o, k) { return Object.prototype.hasOwnProperty.call(o, k); };

    /** printf-style: %s and %d in order, or %1$s / %2$d by position. */
    function format(text) {
        var args = Array.prototype.slice.call(arguments, 1);
        var next = 0;
        return String(text).replace(/%(?:(\d+)\$)?([sd])/g, function (all, pos) {
            var i = pos ? parseInt(pos, 10) - 1 : next++;
            return i < args.length ? String(args[i]) : all;
        });
    }

    /** "hero-split-right" => "Hero split right". */
    function humanize(id) {
        var s = String(id || '').replace(/[-_]+/g, ' ').trim();
        return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
    }

    function slotsOf(catalog, recipe) {
        return catalog && own(catalog, recipe) ? catalog[recipe].slots : [];
    }

    function clone(v) { return JSON.parse(JSON.stringify(v)); }

    var keySeq = 0;

    /** A section of the form. key stays with it through moves, swaps and merges, so a handler or a merge finds it. */
    function newSection(recipe) {
        return { key: 's' + (++keySeq), recipe: recipe, on: true, slots: {}, pictures: {}, auto: {} };
    }

    function indexOfKey(sections, key) {
        for (var i = 0; i < sections.length; i++) {
            if (sections[i].key === key) { return i; }
        }
        return -1;
    }

    function sectionsFromStack(stack) {
        return (stack || []).map(newSection);
    }

    /** A copy of list with the item at from moved to to (clamped). */
    function move(list, from, to) {
        var out = list.slice();
        if (from < 0 || from >= out.length) { return out; }
        to = Math.max(0, Math.min(out.length - 1, to));
        var item = out.splice(from, 1)[0];
        out.splice(to, 0, item);
        return out;
    }

    function filled(v) { return typeof v === 'string' ? v.trim() !== '' : !!v; }

    /** How many items of a section the person filled: its item titles with words in them. */
    function filledItems(section, catalog) {
        var n = 0;
        slotsOf(catalog, section.recipe).forEach(function (slot) {
            if (slot.role === 'item_title' && filled(section.slots[slot.id])) { n++; }
        });
        return n;
    }

    /**
     * The layouts a section can switch to: every recipe with the same role, in catalog order. A layout that holds fewer
     * items than the person filled is not allowed (spec rule 3: more items than a layout holds is prevented).
     */
    function variants(section, catalog) {
        var current = catalog[section.recipe];
        var have = current ? filledItems(section, catalog) : 0;
        var out = [];
        Object.keys(catalog).forEach(function (name) {
            var r = catalog[name];
            if (current && r.role !== current.role) { return; }
            out.push({
                recipe: name,
                role: r.role,
                items: r.items,
                filled: have,
                current: name === section.recipe,
                allowed: name === section.recipe || r.items >= have
            });
        });
        return out;
    }

    function roleKinds(catalog, recipe) {
        var map = {};
        slotsOf(catalog, recipe).forEach(function (s) { map[s.id] = s.role + '/' + s.kind; });
        return map;
    }

    /** Change a section's layout; keeps a value only where id, role and kind all match (StudioMerge::swapRecipe). */
    function swap(section, newRecipe, catalog) {
        if (!own(catalog, newRecipe)) { return { section: section, kept: [], dropped: [] }; }
        var before = roleKinds(catalog, section.recipe);
        var after = roleKinds(catalog, newRecipe);
        var out = { key: section.key, recipe: newRecipe, on: section.on, slots: {}, pictures: {}, auto: {} };
        var kept = [];
        var dropped = [];
        ['slots', 'pictures'].forEach(function (key) {
            Object.keys(section[key] || {}).forEach(function (id) {
                if (!filled(section[key][id])) { return; }
                if (own(after, id) && own(before, id) && after[id] === before[id]) {
                    out[key][id] = section[key][id];
                    if (section.auto && section.auto[id]) { out.auto[id] = true; }
                    kept.push(id);
                } else {
                    dropped.push(id);
                }
            });
        });
        return { section: out, kept: kept, dropped: dropped };
    }

    /**
     * The brief the server expects, from the form state. Only included sections, only slots the recipe has, only words
     * that are not empty; pictures under "pictures". map[k] is the state index of brief section k, keys[k] its key.
     */
    function buildBrief(state, catalog, untitled) {
        var brief = {
            version: 1,
            title: (state.name || '').trim() || untitled,
            goal: state.goal,
            language: state.language,
            sections: []
        };
        if (state.kit) { brief.kit = state.kit; }
        var map = [];
        var keys = [];
        state.sections.forEach(function (section, i) {
            if (!section.on) { return; }
            var out = { recipe: section.recipe };
            var slots = {};
            var pictures = {};
            slotsOf(catalog, section.recipe).forEach(function (slot) {
                if (slot.kind === 'picture') {
                    var p = section.pictures[slot.id];
                    if (p && typeof p === 'object' && (filled(p.pack) || filled(p.url))) {
                        pictures[slot.id] = filled(p.pack) ? { pack: p.pack } : { url: p.url.trim() };
                    }
                } else if (filled(section.slots[slot.id])) {
                    slots[slot.id] = section.slots[slot.id].trim();
                }
            });
            if (Object.keys(slots).length) { out.slots = slots; }
            if (Object.keys(pictures).length) { out.pictures = pictures; }
            brief.sections.push(out);
            map.push(i);
            keys.push(section.key);
        });
        return { brief: brief, map: map, keys: keys };
    }

    function firstSlot(catalog, recipe, roles) {
        var slots = slotsOf(catalog, recipe);
        for (var r = 0; r < roles.length; r++) {
            for (var i = 0; i < slots.length; i++) {
                if (slots[i].role === roles[r] && slots[i].kind === 'text') { return slots[i].id; }
            }
        }
        return null;
    }

    /**
     * Step 1 offered to the opening section (controller ruling 16): the business name as its headline, the one line as
     * its supporting line, the one action as its button label. A field is written only while it is empty or still holds
     * a value put there this way; once the person edits it, it is theirs.
     */
    function applyStepOne(state, catalog) {
        var next = clone(state);
        var hero = null;
        next.sections.forEach(function (s) {
            if (!hero && s.on && catalog[s.recipe] && catalog[s.recipe].role === 'hero') { hero = s; }
        });
        if (!hero) { return next; }
        hero.auto = hero.auto || {};
        [[['headline'], next.name], [['subhead', 'body'], next.line], [['button_label'], next.action]].forEach(function (pair) {
            var id = firstSlot(catalog, hero.recipe, pair[0]);
            if (!id) { return; }
            var value = (pair[1] || '').trim();
            var current = hero.slots[id];
            if (!filled(current) || hero.auto[id]) {
                if (value) {
                    hero.slots[id] = value;
                    hero.auto[id] = true;
                } else {
                    delete hero.slots[id];
                    delete hero.auto[id];
                }
            }
        });
        return next;
    }

    function same(a, b) { return JSON.stringify(a === undefined ? null : a) === JSON.stringify(b === undefined ? null : b); }

    /**
     * Words an assistant wrote into the stored brief, merged into the form. stored is the brief read back, synced the brief
     * last sent from this screen, keys the section key of each section of that brief (so a section moved or left out
     * since is still found). A value is taken when the form's field is empty or still what was last sent; a field the
     * person changed here since is kept and counted.
     */
    function mergeAssistant(state, stored, synced, keys, catalog) {
        var next = clone(state);
        var applied = 0;
        var kept = 0;
        ((stored && stored.sections) || []).forEach(function (sec, k) {
            var i = keys && keys[k] !== undefined ? indexOfKey(next.sections, keys[k]) : -1;
            if (i < 0 || next.sections[i].recipe !== sec.recipe) { return; }
            var target = next.sections[i];
            var base = (synced && synced.sections && synced.sections[k]) || {};
            var kinds = roleKinds(catalog, sec.recipe);
            ['slots', 'pictures'].forEach(function (key) {
                Object.keys(sec[key] || {}).forEach(function (id) {
                    if (!own(kinds, id)) { return; }
                    var incoming = sec[key][id];
                    var current = target[key][id];
                    if (same(incoming, current)) { return; }
                    if (!filled(current) || same(current, (base[key] || {})[id])) {
                        target[key][id] = incoming;
                        if (target.auto) { delete target.auto[id]; }
                        applied++;
                    } else {
                        kept++;
                    }
                });
            });
        });
        return { state: next, applied: applied, kept: kept };
    }

    /** The list of layouts of a brief, in order. */
    function recipesOf(brief) {
        return ((brief && brief.sections) || []).map(function (s) { return String((s && s.recipe) || ''); });
    }

    /**
     * True when two stored briefs differ in anything but words: title, goal, language, kit (none equals empty) or the list
     * and order of layouts. A missing side is not a difference (nothing to compare with).
     */
    function structureChanged(current, synced) {
        if (!current || !synced) { return false; }
        var fields = ['title', 'goal', 'language', 'kit'];
        for (var i = 0; i < fields.length; i++) {
            var a = current[fields[i]] === undefined || current[fields[i]] === null ? '' : String(current[fields[i]]);
            var b = synced[fields[i]] === undefined || synced[fields[i]] === null ? '' : String(synced[fields[i]]);
            if (a !== b) { return true; }
        }
        return !same(recipesOf(current), recipesOf(synced));
    }

    /**
     * A save was refused because the stored brief changed since the screen last synced (an assistant saved). current is
     * the stored brief now. When it differs from synced only in slot or picture words, the answer is { action: 'retry',
     * state, applied, kept }: the state has the assistant's words merged by the mergeAssistant rules, the person's own
     * typing kept. When goal, language, kit, title or the list or order of layouts differ, { action: 'reload' }: nothing is
     * merged and nothing should be sent.
     */
    function resolveConflict(state, current, synced, keys, catalog) {
        if (structureChanged(current, synced)) { return { action: 'reload' }; }
        var m = mergeAssistant(state, current, synced, keys, catalog);
        return { action: 'retry', state: m.state, applied: m.applied, kept: m.kept };
    }

    /**
     * What to send for a save, a create, a rebuild or a hand-off (controller ruling 19): the stored brief is merged in
     * first, so words an assistant wrote since the last sync are kept unless the person changed that field here.
     * stored null means nothing is stored yet. Returns the merged state, the brief, its map and keys, and the counts.
     */
    function prepareSend(state, stored, synced, keys, catalog, untitled) {
        var m = stored ? mergeAssistant(state, stored, synced, keys, catalog) : { state: clone(state), applied: 0, kept: 0 };
        var built = buildBrief(m.state, catalog, untitled);
        return { state: m.state, brief: built.brief, map: built.map, keys: built.keys, applied: m.applied, kept: m.kept };
    }

    /**
     * One busy flag for the actions that write (save, create, rebuild, hand-off). run(fn) returns null when an action is
     * already running (a second click does nothing), else fn's promise; the flag clears when it settles, whatever happens.
     */
    function makeGate(onChange) {
        var busy = false;
        var set = function (v) { busy = v; if (onChange) { onChange(v); } };
        return {
            busy: function () { return busy; },
            run: function (fn) {
                if (busy) { return null; }
                set(true);
                var p;
                try {
                    p = Promise.resolve(fn());
                } catch (e) {
                    p = Promise.reject(e);
                }
                return p.then(function (v) { set(false); return v; }, function (e) { set(false); throw e; });
            }
        };
    }

    /** The width in CSS pixels each preview button means (StudioScreen::DEVICES says the same). */
    var DEVICES = { desktop: 1280, tablet: 768, phone: 390 };
    var MIN_HEIGHT = 360;

    /**
     * The preview box: the frame is laid out at the device's true width (so a desktop is past Divi's 981px breakpoint)
     * and scaled down to fit the pane, never up. width/height are the frame's own size, wrapWidth/wrapHeight the scaled
     * size the wrapper takes (so the unscaled box makes no overflow); wrapHeight is the target height. A pane with no
     * width yet (hidden, not laid out) is not scaled.
     */
    function frameBox(paneWidth, device, targetHeight) {
        var width = own(DEVICES, device) ? DEVICES[device] : DEVICES.desktop;
        var pane = typeof paneWidth === 'number' && isFinite(paneWidth) ? paneWidth : 0;
        var scale = pane > 0 ? Math.min(1, pane / width) : 1;
        var target = Math.max(MIN_HEIGHT, typeof targetHeight === 'number' && isFinite(targetHeight) ? Math.round(targetHeight) : 0);
        var wrapWidth = Math.round(width * scale);
        if (pane > 0) { wrapWidth = Math.min(Math.floor(pane), wrapWidth); }
        return { width: width, scale: scale, height: Math.round(target / scale), wrapWidth: wrapWidth, wrapHeight: target };
    }

    /** Problems by state section ({path, code, message} lists); a path outside sections.N goes to page. */
    function problemsBySection(problems, map) {
        var out = { page: [], sections: {} };
        (problems || []).forEach(function (p) {
            var m = /^sections\.(\d+)(?:\.(.*))?$/.exec(String((p && p.path) || ''));
            var i = m ? map[parseInt(m[1], 10)] : undefined;
            if (i === undefined) {
                out.page.push(p);
                return;
            }
            var slot = m[2] ? m[2].replace(/^(slots|pictures)\./, '') : '';
            (out.sections[i] = out.sections[i] || []).push({ path: p.path, code: p.code, message: p.message, slot: slot });
        });
        return out;
    }

    /** report.unfilled ({section, slot, role}) by state section. */
    function unfilledBySection(unfilled, map) {
        var out = {};
        (unfilled || []).forEach(function (u) {
            var i = map[u.section];
            if (i === undefined) { return; }
            (out[i] = out[i] || []).push({ slot: u.slot, role: u.role });
        });
        return out;
    }

    function origin(url) {
        var m = /^(https?:\/\/[^/?#]+)/i.exec(String(url || ''));
        return m ? m[1].toLowerCase() : null;
    }

    /**
     * A Media Library address as the brief takes it: an address on this site becomes its path (/wp-content/...), so an
     * http site works too; another https address stays; anything else is null.
     */
    function toSitePath(url, home) {
        url = String(url || '').trim();
        var o = origin(url);
        var h = origin(home);
        if (o && h && o === h) {
            var rest = url.slice(o.length);
            return rest.charAt(0) === '/' ? rest : '/' + rest;
        }
        return /^https:\/\//i.test(url) ? url : null;
    }

    /** An address the screen may link to: only one on the same site as the screen. */
    function sameSiteUrl(url, here) {
        return origin(url) !== null && origin(url) === origin(here) ? String(url) : null;
    }

    /**
     * The address of this screen with &brief=<id> (an earlier brief argument replaced, the others and the hash kept), so
     * a reload reopens the brief. Anything but a positive whole number leaves the address as it is.
     */
    function briefUrl(href, id) {
        var n = typeof id === 'number' ? id : (/^[1-9][0-9]{0,9}$/.test(String(id)) ? parseInt(id, 10) : 0);
        href = String(href || '');
        if (!(n > 0 && Math.floor(n) === n)) { return href; }
        var hash = '';
        var h = href.indexOf('#');
        if (h >= 0) { hash = href.slice(h); href = href.slice(0, h); }
        var q = href.indexOf('?');
        var path = q >= 0 ? href.slice(0, q) : href;
        var args = q >= 0 ? href.slice(q + 1).split('&').filter(function (a) { return a !== '' && a.split('=')[0] !== 'brief'; }) : [];
        args.push('brief=' + n);
        return path + '?' + args.join('&') + hash;
    }

    /** The brief the screen would send now, as one string (what "saved" is compared with). */
    function briefKey(state, catalog, untitled) {
        return JSON.stringify(buildBrief(state, catalog, untitled).brief);
    }

    /** True while the answers differ from the brief last saved or loaded (savedKey from briefKey, or null). */
    function isDirty(state, savedKey, catalog, untitled) {
        return savedKey === null || savedKey === undefined || briefKey(state, catalog, untitled) !== savedKey;
    }

    /** What the preview frame does after an action: a successful create deletes the preview draft, so it is cleared. */
    function frameAfter(action, ok) {
        return action === 'create' && ok ? 'clear' : 'keep';
    }

    /** The form state from a stored brief: which sections lost their layout, which saved words lost their place. */
    function fromStored(brief, catalog) {
        var state = {
            name: typeof brief.title === 'string' ? brief.title : '',
            goal: brief.goal,
            language: brief.language,
            kit: typeof brief.kit === 'string' ? brief.kit : '',
            sections: []
        };
        var gone = [];
        var stale = {};
        (brief.sections || []).forEach(function (sec, i) {
            var s = newSection(String(sec.recipe || ''));
            s.slots = clone(sec.slots || {});
            s.pictures = clone(sec.pictures || {});
            if (!own(catalog, s.recipe)) {
                gone.push(i);
            } else {
                var kinds = roleKinds(catalog, s.recipe);
                var lost = Object.keys(s.slots).concat(Object.keys(s.pictures)).filter(function (id) { return !own(kinds, id); });
                if (lost.length) { stale[i] = lost; }
            }
            state.sections.push(s);
        });
        return { state: state, gone: gone, stale: stale };
    }

    return {
        format: format,
        humanize: humanize,
        newSection: newSection,
        sectionsFromStack: sectionsFromStack,
        move: move,
        filledItems: filledItems,
        variants: variants,
        swap: swap,
        buildBrief: buildBrief,
        applyStepOne: applyStepOne,
        mergeAssistant: mergeAssistant,
        structureChanged: structureChanged,
        resolveConflict: resolveConflict,
        prepareSend: prepareSend,
        makeGate: makeGate,
        DEVICES: DEVICES,
        frameBox: frameBox,
        indexOfKey: indexOfKey,
        problemsBySection: problemsBySection,
        unfilledBySection: unfilledBySection,
        toSitePath: toSitePath,
        sameSiteUrl: sameSiteUrl,
        fromStored: fromStored,
        briefUrl: briefUrl,
        briefKey: briefKey,
        isDirty: isDirty,
        frameAfter: frameAfter
    };
}));
