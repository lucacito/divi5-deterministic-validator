=== JHMG AI Editor for Divi 5 ===
Contributors:      lucaslopvet
Tags:              divi, divi 5, mcp, claude, chatgpt
Requires at least: 6.0
Tested up to:      7.1
Stable tag:        4.19.0
Requires PHP:      8.1
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Design guidance, validation and undo for any AI working on Divi 5. Designed to work alongside Divi's upcoming MCP.

== Description ==
**Design guidance, validation and undo for any AI working on Divi 5.** Connect Claude, ChatGPT, Cursor, VS Code Copilot, Windsurf or Gemini to your WordPress site, then tell it in your own words what to change on your Divi 5 pages, or to build a new one. A built-in checker tests every change before it is saved, and every change can be undone.

The Model Context Protocol (MCP) server runs on your own site. The plugin uses no cloud service and no account, and nothing is sent to us.

= Designed to work alongside Divi's upcoming MCP =

The plugin is designed to work alongside Divi's upcoming MCP and any other tool that builds Divi pages. It has not been tested against Divi's MCP yet, because that has not been released. It adds design guidance before the build (10 design languages and 75 proven section patterns), a fixed-rule check after it, and undo for every change, whichever tool made it. These are offered as WordPress abilities on WordPress 6.9 and later. It never wraps, blocks or changes another tool's abilities.

= How it works =

1. Connect your own AI assistant with one key (copy and paste, about two minutes).
2. Tell it what you want in plain English, for example "change the phone number on the Contact page" or "build me a landing page for my dental clinic".
3. The built-in guides steer it, a checker refuses a broken layout with the exact reason, and the previous version of the page is kept so you can undo.

More detail is in the FAQ below: the tools, the checker, privacy, images and compatible assistants.


== External services ==

This plugin does not connect to any external service. Your AI assistant connects to your own site using the API key you generate (or, if you turn it on, by signing in to your own site from Claude on the web); no data passes through the plugin author's servers.

== Installation ==

1. In your WordPress admin, go to Plugins → Add New, search for "JHMG AI Editor for Divi 5", then install and activate it. (Or upload the `jhmg-ai-editor-for-divi-5` folder to `/wp-content/plugins/` and activate it on the Plugins screen.)
2. Open **AI Editor** in your WordPress admin sidebar.
3. Go to **Settings**, choose your AI assistant and copy the ready-made setup into it.
4. Ask your assistant to list your Divi 5 pages to check that it is connected.

= Requirements =

* WordPress 6.0 or later
* PHP 8.1 or later
* The Divi 5 theme (Divi 4 and its shortcode format are not supported)
* Pretty permalinks (Settings → Permalinks, any option except "Plain")
* For Claude Desktop: Node.js (free, from nodejs.org)
* For Claude on the web (claude.ai): your site must be reachable over public HTTPS
* For ChatGPT: your site must be reachable over public HTTPS, you must turn on the sign-in in Settings, and custom connectors need a paid ChatGPT plan with Developer mode

== Frequently Asked Questions ==

= Why an MCP server built only for Divi 5? =

Divi 5 stores a page as strict block data. A general-purpose assistant can save something that looks right in the code and still cannot be opened in the builder. This plugin gives your assistant Divi 5's real rules, proven section patterns and a checker that refuses a broken layout with the exact reason, so the assistant can fix it and save a page that works.

= Rebuild a page from a screenshot or a URL =

1. Give your assistant a screenshot, the address of a page, or the page's HTML.
2. Ask it to build that page in Divi 5. It is always saved as a draft.
3. It reads this plugin's guides, picks matching section patterns, a design language and a style kit, writes the layout, and the checker tests it before it is saved.
4. Review the draft, swap in your own text and images, and publish.

What to expect: your assistant, not the plugin, looks at the picture or reads the page, so the result follows the design closely but is not pixel-for-pixel. Photos from the original are never copied: the draft uses your Media Library images, or the plugin's built-in pictures as placeholders. If you already have the page's HTML, the `html_to_divi` tool turns it into a Divi 5 layout and reports anything it left out.

= How it works (in plain words) =

1. Connect your own AI assistant (Claude, ChatGPT, Cursor or Copilot) to your site with one key. It is copy and paste, and takes about two minutes.
2. Tell it what you want in plain English, for example "change the phone number on the Contact page" or "build me a landing page for my dental clinic".
3. The plugin's built-in guides and proven section patterns steer the AI, so it builds real, good-looking Divi 5 pages instead of guessing. It uses your own Media Library images when it can.
4. Before anything is saved, a built-in checker tests the page against fixed rules. If something is wrong, the change is refused with the exact reason and the AI fixes it. If it is fine, it is saved, and the previous version is kept so you can undo.

= What makes it smart =

* **The checker is not AI.** It follows fixed rules: same page in, same verdict out. The AI can be creative, but every save it makes is checked first, so a broken page is never saved by an AI edit.
* **It knows Divi 5 well.** The checker knows more than 80 Divi 5 block types (modules, sections, rows and columns) and which ones are allowed inside which.
* **Rules come from real Divi 5, not guesses.** The rules come from real Divi 5 page exports and, for 24 newer modules (and their child items), from Divi's own module definitions, verified by rendering them in real Divi 5.15.
* **Understands Divi 5.15 components.** Pages that use shared components (reusable sections, rows and modules, including ones with Slots) can be read and edited. Your AI can see which components your site has and is told when a change would do nothing because the component owns that part.
* **Warns before a page is hollowed out.** If a save would remove more than half of a page's text, images or modules, your AI is told and can put it back. Nothing is stopped: a deliberate rewrite is still yours to make.
* **Small changes stay small.** Changing one phone number replaces just that text. The rest of the page is not rebuilt or touched.
* **Preview before saving.** Your AI can ask what a change would do before it saves anything. It gets a list of the blocks and settings that would change, and the checker's verdict. Nothing is saved until it repeats the request for real.
* **Matches your site.** Your AI can look up your site's own Divi colors and presets and reuse them, and it is told when a page uses one your site does not have. It cannot create or change presets or colors: that stays in Divi's Visual Builder.
* **Proven building blocks.** 75 ready-made section patterns (heroes, feature grids, testimonials, contact forms and more), each one tested against the checker, plus landing-page guidance on the order of sections, headlines and calls to action.
* **Consistent looks.** Ten design languages (editorial, glass dark, organic warm, tech mono and more) and 40 style kits set the exact look of buttons, cards, accordions, toggles, contact forms and image corners, so a whole page matches.
* **Sensible images.** The AI looks in your Media Library first. When nothing there fits, it uses a built-in pack of 44 original images that ships with the plugin.
* **One-click undo.** The previous version of each page or Divi Project the AI changes is kept (up to the last 10). Restore it from the plugin's Dashboard with one click, or just ask your AI to undo.
* **Works with the AI assistant you already use.** Claude, ChatGPT, Gemini, Cursor, VS Code Copilot, or any assistant that supports MCP.
* **Nothing leaves your site through the plugin.** It uses no third-party services. Your AI assistant talks directly to your own site.

= Examples to try =

* "Change the phone number on the Contact page to 555-0142."
* "Make the main heading on the Home page say 'Fresh bread every morning'."
* "Build me a landing page for my dental clinic, with a booking button and three patient reviews."
* "Add a section with our opening hours under the hero on the About page."
* "Undo the last change you made to the Services page."

= What your AI assistant can do (22 tools) =

Read and check:

* `list_divi_pages`: list the pages built with Divi 5 that you can edit (pass post_type project to list Divi Projects).
* `get_page_layout`: read the current layout of a page or Divi Project. For a big page your assistant can read just an outline (every block with its place, size and the start of its text) or one block, which costs a fraction of reading the whole page.
* `list_global_styles`: list your site's own Divi colors and presets so the AI can reuse them (read-only).
* `get_site_structure`: list your site's custom post types, taxonomies, image sizes, Divi 5.15 components (name, kind, Slots, how many pages use each), on request the names and ids of your site's navigation lists and of your most used categories and tags (so a list on a page can name them), and Advanced Custom Fields field groups so pages fit your site (read-only: field names and the keys your posts use, never values here or theme files; available over MCP and the REST API, not in the ChatGPT Action).
* `get_custom_fields`: read the custom fields of one page or Divi Project you can edit, with their values, so your assistant can write copy that fits and use the right field names (read-only: keys WordPress protects, or that look like passwords, API keys or other secrets, are never shown; available over MCP and the REST API, not in the ChatGPT Action).
* `list_products`: list and count your WooCommerce products with their prices, stock status and categories (read-only; needs the permission to edit products; available over MCP and the REST API, not in the ChatGPT Action).
* `get_product`: read one WooCommerce product in full, including its variations (read-only; never downloadable files, purchase notes or custom fields).
* `validate_layout`: check a layout without saving anything.

Edit and create:

* `edit_page_content`: change one piece of text (an email, phone number, price or sentence) without rebuilding the page or Divi Project. Add `dry_run` to preview the change without saving it.
* `update_page_layout`: save a new layout for a page or Divi Project, after the checker approves it. Add `dry_run` to preview what would change without saving it.
* `create_page`: create a new page. It is always saved as a draft for you to review and publish.
* `html_to_divi`: turn HTML you already have (a page your assistant or another tool wrote) into a Divi 5 layout: the structure, all the copy, the links and the images, plus the basic colors, fonts and spacing where Divi can show them and the text stays readable. It previews by default and saves a new draft only when asked. Scripts, forms, embeds and site navigation are never converted and are listed in a report (available over MCP and the REST API, not in the ChatGPT Action).

* `lab_build`: lets your assistant use Lab (see "Lab: answer a few questions, see a preview" below). It can read a Lab brief you started and fill in the words, telling it which parts are still empty and never overwriting what you changed meanwhile, or build a whole page from a short brief. It is always saved as a draft, after the checker approves it. New: results with a given assistant have not been confirmed yet (available over MCP and the REST API, not in the ChatGPT Action).

Undo:

* `list_page_history`, `get_page_history_entry`, `restore_page_version`: see the saved earlier versions of a page or Divi Project and bring one back.

Guides that help the AI build good pages:

* `get_style_guide`: how to build styled Divi 5 layouts, using real Divi 5 settings.
* `get_landing_guide`: how to build a landing page that turns visitors into customers.
* `get_site_guide`: how to plan a site with several pages that link to each other.
* `get_section_recipes`: the 75 ready-made section patterns.
* `get_image_guide`: how to pick the right image for each section, including the built-in image pack.

Images:

* `list_media_images`: look through the images already in your Media Library (read-only; nothing is uploaded, changed or deleted).

= Abilities for other AI tools (WordPress 6.9 and later) =

On WordPress 6.9 and later the plugin also registers these abilities in the `jhmg-ai-editor` category, for any assistant or MCP adapter that can call WordPress abilities. They check the same permissions as the tools above (a signed-in user who can edit pages, and edit permission on the page itself) and nothing is public.

* Guidance: `get-style-guide`, `get-landing-guide`, `get-site-guide`, `get-image-guide`, `get-section-recipes` (filter by role, layout, mood, density and persuasion stage), `get-design-languages` and `get-variety-advice`.
* Checks: `validate-layout` and `check-design`.
* Pages and undo: `list-divi-pages`, `get-page-layout`, `update-page-layout`, `edit-page-content`, `create-page`, `list-page-history`, `get-page-history-entry` and `restore-page-version`. Every save is still checked first.

On older WordPress versions these abilities are simply not offered; everything else works the same.

= Lab: answer a few questions, see a preview =

New in 4.19.0. The Lab tab in the plugin's admin page builds a page without writing a prompt. You answer a few questions (what the page is for, the look, the sections, your words and pictures), see a live preview, and save a draft page. The page is made from the plugin's proven section layouts and is checked before it is saved, like every other change. Your assistant can also fill in the words of a brief you started, through the `lab_build` tool, and it never overwrites what you changed in the meantime. Lab is new, and results with any particular assistant have not been confirmed yet.

= Images =

The plugin includes a pack of 44 original images (hero backgrounds, card and section images, people placeholders and logo placeholders) made for this plugin and bundled inside it. Your AI uses your own Media Library images first and the built-in pack when nothing fits. Nothing is downloaded from other websites.

= Add-on =

A separate, optional Pro add-on is available (details at https://divi5lab.com/plugins/divi-5-ai-editor). This plugin is complete on its own and works the same without it.

= Compatible AI assistants =

* Claude on the web (claude.ai custom connector), by signing in to your own site (turn it on in Settings; needs a public https address)
* Claude (Desktop and Claude Code), through MCP (Claude Desktop needs Node.js installed)
* Gemini CLI, through MCP
* Cursor and Windsurf, through MCP
* VS Code with GitHub Copilot, through MCP
* ChatGPT, through a custom connector that signs in with your WordPress login (needs Developer mode on a paid ChatGPT plan; set up for OpenAI's published requirements but not yet confirmed by us), or, while OpenAI still allows it, a custom GPT Action (OpenAPI)
* Any other MCP client, or any HTTP client through the REST API

Works with Divi 5. Divi is a trademark of Elegant Themes. This plugin is not affiliated with, endorsed by, or sponsored by Elegant Themes.

= Privacy =

The plugin stores these things in your own WordPress database:

* The API key (and which user it belongs to).
* Only if you turn on sign-in for Claude on the web: the apps that registered, and their access and refresh tokens, in a table in your own database. The tokens are stored only as one-way hashes and you can disconnect any app, or turn the feature off and remove everything, from the Settings screen.
* An activity log of AI actions: the action, the page ID, the result, the assistant's name (or, when it is not recognised, the first 80 characters of its user-agent string) and a hashed IP address (hashed with your site's own secret key, so the IP itself is not stored). You can clear it from the Settings screen.
* Whether you chose "Maybe later" or "Don't ask again" on the review reminder (one value per user, shown only on the plugin's Dashboard after the plugin has saved at least 5 changes). Nothing is sent when you choose, and the reminder's link only opens this plugin's own page on WordPress.org if you click it.
* Page history for undo: up to the last 10 previous versions of each Divi page that an AI tool changes (fewer for very large pages, about 768 KB per page at most). This includes changes made by other tools, such as an application password or the REST API: the page's earlier content is kept, with where the change came from (the name of the ability, or the name you gave the application password; never a password or key). It is kept in a table in your own database, and you can switch each source off in Settings.

Nothing is sent anywhere by the plugin. All of this is removed when you delete the plugin.

= Does the AI get administrator access to my site? =

No. The API key works as the WordPress user who created it, and the AI can only use this plugin's tools. Every request checks that this user can still edit pages, and every page listing, read or change, every new page and every Media Library lookup re-checks that user's WordPress permissions (pages they cannot edit are not even listed). The tools can only list, read, check, edit and undo the content of pages and Divi Projects, create pages (as drafts), read Media Library images (read-only), read your site's Divi presets and colors (read-only), read how your site is set up (post types, taxonomies, image sizes and ACF field definitions, read-only), read the custom fields of a page or Divi Project you can edit (read-only), and read your WooCommerce products (read-only). They cannot install plugins, change users, settings, menus or the front page, or run PHP or other server-side code.

= Can the AI add custom CSS, JavaScript or PHP to my site? =

No. The checker refuses any layout that contains custom CSS, a Divi Code module, script, style or iframe markup, a javascript: link or an event attribute, and the plugin has no tool that saves CSS, JavaScript or PHP or changes site settings. Anything already on a page, for example custom CSS you added in the Visual Builder, is kept: the AI cannot add or change code (it can only remove it).

= Where do images come from? =

From your own Media Library first. When nothing there fits, the AI uses the built-in image pack that ships inside the plugin. Nothing is downloaded from third-party websites.

= Is my data sent anywhere? =

No. The plugin does not send your data anywhere and uses no third-party services. Your AI assistant connects directly to your site with your key. The page content your assistant reads is handled by the AI service you chose (for example Anthropic or OpenAI), under that service's own terms.

= Can the AI break my pages? =

The AI can make mistakes, but a broken page is never saved by an AI edit. The checker runs before every save. If a layout breaks a rule, it is refused, nothing is saved, and the AI gets the exact reason so it can fix it. If you do not like a change that was saved, restore the previous version from the Dashboard: undo puts back your own earlier version exactly as it was, and when your AI assistant does the restore it is told whether that version passes the checker.

= Is the API key safe? =

The key is a long random code stored in your WordPress database and shown only to administrators on the plugin's Settings screen. Keep it private, like a password. You can make a new one at any time with the Regenerate button, which stops the old one from working.

= Is it dangerous to let AI edit my site? Is there an approval step? =

Every save is checked by a fixed set of rules (no AI is involved in the check) and a broken layout is refused. You can ask your assistant for a preview first (a dry run shows what would change and saves nothing), new pages are always drafts, and every save can be undone from the Dashboard. The plugin cannot change your site settings, users or plugins, and cannot add custom code. If you want a stricter rule, turn on Approval mode in Settings ("Require a preview before every save"): your assistant must then preview every edit to a page's content before it can save it. Restoring an earlier version is the undo and needs no preview.

= Why do I need this if Claude can already control a browser? =

The plugin edits the Divi 5 layout data directly, so it is faster and more precise, every change is checked before it is saved, and every save can be undone. An assistant that drives a browser works from screenshots and clicks, and nothing stops it from saving a broken layout.

= Does the checking use up my AI tokens? =

No. The check runs in PHP on your own server. Your assistant only reads what the plugin sends back: the tool list it loads once per conversation (about 4,000 tokens), reading the page it is editing (about 300 to 16,500 tokens depending on its size), and the details of what was wrong when a layout is refused (about 400 tokens for one unknown block). These are estimates; the real count depends on the model.

= Does it work with Gemini? =

Yes. It has been tested with Gemini CLI: copy the one command from the Gemini tab on the Settings screen. Any assistant that supports remote MCP servers can connect.

= Does it work with WooCommerce? =
Yes, for reading. Your assistant can list and count your products and read one product in full (name, description, price, stock, categories, variations), so it can answer store questions and write shop pages that match your catalogue. It never changes a product: prices and stock are not touched by this plugin.

= Can it read my ACF fields, custom post types or functions.php? =

It can read how your site is set up: custom post types, taxonomies, image sizes, on request the names and ids of your site's navigation lists (never their links) and of your most used categories, tags and other public taxonomy terms, and, when Advanced Custom Fields is active, its field groups and fields (names, labels, types and choices). It reads custom field values only when your assistant asks about one specific page or Project you can edit, never ones WordPress protects or that look like passwords, API keys or other secrets, and it never reads your theme files or `functions.php`. This is available to assistants that connect over MCP or the REST API, not to the ChatGPT Action.

= Can it create global colors and presets? =

No. It reads the ones you already have, reuses them, and warns when a layout uses one your site does not have. It never creates, changes or deletes them.

= Does it work on a local site? =

Assistants that run on your own computer (Claude Code, Claude Desktop, Cursor, VS Code, Gemini CLI) should be able to reach a local site. Use the exact http:// address your local site shows, and turn on pretty permalinks. ChatGPT and other assistants that run in the cloud cannot reach a local site; they need a public https:// address. Local tools such as Laragon, Local or MAMP work with the assistants that run on your computer.

= I get an error on my Mac when I connect Claude Desktop =

Claude Desktop connects through a small helper that needs Node.js. Install the LTS version from nodejs.org, then fully quit Claude Desktop (Cmd+Q) and open it again. The Claude tab on the Settings screen has the details.

= My host cuts me off after I connect (too many 404 errors) =

Some hosts run a firewall rule (for example ModSecurity's "too many 404 responses from same IP") that bans an address after about ten "not found" answers. The plugin does not cause 404s on its own address: when an assistant opens the connection with a GET request, it answers 405 (Method Not Allowed), which is what the MCP specification asks for and which these rules do not count. Some connection helpers, such as the mcp-remote helper that Claude Desktop uses, also look for sign-in information at addresses like /.well-known/oauth-protected-resource. If Claude sign-in is switched off, there is nothing at those addresses, so WordPress answers 404, and several reconnects in a row can still add up. If you get banned, ask your host to allow your own IP address, or to raise the limit for it.

Another option is a small connector that a user, Brandon McCloskey (Web Design by Brandon), has shared as a public GitHub Gist called "wp-mcp-bridge" (MIT licence, needs Node.js 18 or newer). It only sends requests to the connection address, so it never causes 404s. It is not made or checked by us, and it handles your API key, so read any script like this before you use it.

= Does it use up my Claude or ChatGPT plan? =

The plugin has no AI of its own, so it adds no AI cost. Your own assistant does the thinking, and its usage counts against whatever plan or API account you already use with it. A small edit costs very little; building a whole page costs more, because your assistant writes the layout. The plugin's checking runs on your server and is free.

= How is this different from Divi AI? =

Divi AI is Elegant Themes' own AI inside the Divi builder. This plugin does something different: it lets the AI assistant you already use (Claude, ChatGPT, Gemini, Cursor, Copilot) read and edit your Divi 5 pages from outside the builder, in plain English. Every change is checked before it is saved and can be undone.

= How is it different from other AI plugins for WordPress? =

It is built for one job: editing Divi 5 layouts safely on a live site. It knows the Divi 5 page format, refuses any layout that is broken before it is saved, offers a preview of every change, makes new pages drafts, and keeps an undo history. It does not run code on your site and does not change your site settings.

= Do I need this if I use Divi's MCP? =

Divi has announced its own MCP, which is not released yet, so this plugin has not been tested against it. A builder builds pages. This plugin is designed to add what a builder does not: ten design languages and 75 proven section patterns to design from, a deterministic checker that refuses a broken layout with the exact reason, an advisory design check (readability, Divi's stock look, repeated sections), and undo for every change, even ones made by other tools. The idea is to use both: ask your assistant to read this plugin's design guidance before it builds, build with any tool, then run the design check and fix what it finds.

= Is this an MCP server for Divi? =

Yes. The plugin adds a Model Context Protocol (MCP) server to your own WordPress site, with 22 tools made for Divi 5 pages and Divi Projects. Any MCP client can use it: Claude, Cursor, Windsurf, VS Code with GitHub Copilot, Gemini CLI and others. ChatGPT connects through a custom connector that signs in with your WordPress login and gets every tool (the older custom GPT Action offers most of them).

= Can I give it a screenshot or a URL and have it copy a page? =

Yes, through your AI assistant. Give the assistant a screenshot or the address of a page and ask it to build that page in Divi 5. It uses this plugin's guides and section patterns, writes a layout, and the checker tests it before it is saved as a draft. The plugin itself does not look at images or fetch websites, and photos are never copied, so expect a close match to the design with your own images and text swapped in.

= Can I use Claude on the web (claude.ai) without installing anything? =

Yes. On the Settings screen, turn on sign-in for Claude and copy the address it shows. In claude.ai open Customize → Connectors, choose "Add custom connector" and paste the address. Claude opens your own site: you sign in to WordPress and press Allow. There is no Node.js, no config file and no API key to paste. Claude then works as you, with exactly the permissions your account has, and every save is still checked and undoable. You can disconnect it from the Settings screen at any time. It needs your site to be reachable over public https (Claude connects from the internet), so it does not work on a local site; the other ways of connecting are unchanged. It is off until you turn it on.

= Can it turn my HTML page into a Divi page? =

Yes, for the content. Give your assistant the HTML (for example a page it wrote for you) and it can convert it with `html_to_divi`: the structure (sections, columns for card grids, headings, text, buttons, images), every word and every link. It previews first and tells you what was not converted; with one more step it saves a draft. Scripts, forms, embedded videos, site navigation and CSS code are never converted; it carries the basic colors, fonts and spacing of the HTML where Divi can show them, and never a color that would make text hard to read; linked stylesheets are not fetched, so a page that keeps its styling in an external file comes out plainer; and images become placeholders for you to replace with your own. It does not fetch web addresses. For a pixel-accurate copy of a live web page you need a dedicated URL-to-Divi converter instead.

= Can the AI change a page's title? =

Yes. Ask your assistant to rename the page and it uses the update_page_layout tool with a new title (the page can be a Divi page or a Divi Project). This changes the WordPress page title: what shows in the page list and, by default, the browser tab. It is not the same as the big headline (the h1) inside the page layout, which is part of the layout and is changed separately; if the two match, your assistant should ask whether you want both changed. It changes only the title: not the page address (slug). A title change is not covered by Undo, so your assistant tells you the old title when it changes one, and a title change is not listed under "Recent AI edits" on the dashboard, because that list shows saved versions you can restore and a title change has none. You can ask for a preview first.

= Does this work with Divi 4? =

No. Divi 4 stores pages as shortcodes. This plugin is made for the Divi 5 page format.

= Can it edit pages that use modules from other Divi add-on plugins? =
Not yet. The checker only knows Divi's own modules, so it refuses to save a page that contains a module from another plugin (for example Divi Pixel or Divi Plus), even for a text change. Your assistant can still read such a page, and it can edit every other page. Nothing is changed on a refused save, and the reply tells your assistant exactly which block was not recognised.

= Does it work on staging sites or multisite? =

It works on any standard WordPress site, including staging sites. Multisite is not officially supported yet.

= Will this slow down my site? =

No. The plugin adds no scripts or styles to your public pages. It only adds its admin screen and the connection endpoints your AI assistant uses.

== Screenshots ==

1. The Dashboard: your setup progress and your results.
2. Settings: one API key, a copy-and-paste setup for Claude, Cursor, VS Code, Gemini, ChatGPT or any MCP client, and a Test connection button that checks your setup and shows plain-English errors if anything is wrong.
3. Features: everything your AI assistant can do on your Divi 5 site.

== Changelog ==

= 4.19.0 =
* New: Lab. A page builder screen in the plugin (the Lab tab) where you answer a few questions (what the page is for, the look, the sections, your words and pictures), see a live preview, and save a draft page. The page is built from the plugin's proven section layouts, so it is checked before it is saved, like every other change.
* New: `lab_build`, the tool that lets your AI assistant use Lab. It can read a Lab brief you started and fill in the words (it is told which parts are still empty and never overwrites what you changed in the meantime), or build a whole page from a short brief and save it as a draft. The brief is much smaller than the Divi markup of the same page. Available over MCP and the REST API, not in the ChatGPT Action. It is new: results with a given assistant have not been confirmed yet.
* Improved: the Lab screen keeps your changes and your assistant's words apart. If your assistant fills in words while you have the screen open, nothing is lost: the screen merges them, or asks you to reload if the structure changed.
* Changed: 22 tools instead of 21 (`lab_build`).

= 4.18.0 =
* New: Divi's Loop Builder. Your AI can build lists that repeat once per post, product, category, user or navigation item, and page through them with Next and Previous links. The style guide has a new `loops` topic, and there are four ready-made patterns: the newest posts, all posts in pages, the site's categories and the newest products.
* New: the checker refuses the loop settings that make Divi fail the whole page (HTTP 500) or quietly list the wrong things, and says exactly which setting to fix.
* New: when your AI saves, checks or previews a page with a loop, it also gets a short report of what each loop will show on your site (how many items and the first titles). It flags a post type, category, term ID or navigation list your site does not have, and mistakes such as a post token in a navigation loop or two loops sharing one ID. Advice only: it never blocks a save.
* New: `get_site_structure` can also list the names and IDs of your site's navigation lists and of your most used categories and tags (ask for them with `include`). Read-only.
* Improved: four new loop patterns join the ready-made library.
* Improved: when a dynamic-content token is written with plain quotes inside a block, the refusal now says how to write it.
* Tested on Divi 5.15.1. Not covered yet: ACF repeater loops with a real repeater field, loops inside site-wide templates, and Divi's Post Filter module.

= 4.17.0 =
* New: the plugin is designed to work alongside Divi's upcoming MCP and any other tool (not yet tested against Divi's MCP, which is not released). On WordPress 6.9 and later it offers its design guidance, the checker, a new design check and page history as WordPress abilities (17 of them, in the `jhmg-ai-editor` category), with the same permissions as before.
* New: `get-design-languages` returns the ten design languages with colors, fonts, shape, spacing, what to avoid and contrast-checked pairings. `get-section-recipes` can also be filtered by density and persuasion stage. `get-variety-advice` finds repeated section layouts and names recipes to try.
* New: `check-design` is an advisory check of any Divi 5 layout: text that cannot be read (only definite failures, with the colors and the ratio), Divi's grey placeholder images and stock button or tab bar, ids of colors and presets your site does not have, and repetitive sections. It never blocks or changes a page and says what it could not check.
* New: undo for changes made by other tools. Before a Divi page is changed by another plugin's ability (such as Divi's upcoming MCP), an application password or the REST API, the previous version is kept and labelled with its source, and the Dashboard shows the source. Divi's visual builder is off by default because WordPress revisions already cover it. Choose the sources in Settings.
* New: a short "What's new" panel at the top of the plugin's own Dashboard (once per version, dismissible per user). It never appears anywhere else in the admin.
* Improved: the Settings screen has a short text you can paste into your assistant so it uses these abilities alongside Divi's upcoming MCP.
* No change to the existing 21 tools, the REST routes or the ChatGPT OpenAPI spec; they are pinned byte for byte by tests.

= 4.16.0 =
* Improved: ChatGPT can now connect as a custom connector, which signs in with your WordPress login. OpenAI is retiring custom GPTs, and their Actions do not carry over. The Settings screen explains the new steps and keeps the old ones for GPTs you already built. We have followed OpenAI's published requirements but have not yet been able to test with a ChatGPT account.
* Improved: the sign-in switch in Settings now says it covers Claude on the web and ChatGPT.

= 4.15.0 =
* New: a page keeps one look from the headlines down. Headline weight, letter spacing and capital letters now follow the chosen design language (a luxe page gets light, wide-spaced labels, a brutalist page heavy capitals), and the space between sections follows it too (a tight language gets tight sections, an airy one airy sections).
* New: style kits now also set the look of a testimonial card, the icon of a blurb, the rule above a counter and the accent divider line, so they match the buttons and cards around them.
* New: the checker now refuses 80 content shapes that make Divi answer "500 error" for the whole page, for example a testimonial's company written as plain text, or a heading's title written as an object. It reports exact violation codes so your assistant fixes the layout and retries. Found by rendering every content field of every Divi module on a real Divi 5.15.1 site.
* New: a "kit-patterns" guide topic teaches your assistant how to write rows of tags and icon badges, price columns with a featured plan, rules, dividers and hover colors by hand. `get_style_guide` takes an optional `design_language`, so the kit topics show their examples in your language's colors and fonts.
* Improved: a button that swaps its colors on hover now keeps its frame on hover, so it no longer loses its outline (this showed with the glass edge and heavy block kits).
* Improved: in the built-in section patterns, headline weight and the space between sections now come from the design language. With the default look (editorial) some headlines are a little bolder than before and some sections are spaced differently.
* Improved: the guide's language descriptions agree with the kits (a language no longer describes a card or button color the kit sets differently), and it says titles stay in normal case when a language only asks for capital letters in headlines.
* Improved: verified on Divi 5.15.1.

= 4.14.0 =
* New: style kits now also set the look of divider lines, the rules between list items and price columns, small tag labels and icon badges (line style, width and corners), so a dashed, dotted or heavy kit reads as one design all the way down.
* Improved: the guide now tells your assistant exactly how to write those by hand (widths, which settings to use, and that the kit wins when a design language says something different). Found by having fresh assistants build pages from the guide alone.
* Improved: in the built-in section patterns the thin rules and the icon badges follow the chosen kit. With the default look some lines are a little heavier and icon badges are squarer.
* New: `html_to_divi` now carries the HTML's basic colors, fonts, sizes, alignment, backgrounds and spacing (and a button's colors and corners) where Divi can show them, and drops any color that would make text hard to read. The report lists what was carried and what was left out.
* Fixed: `html_to_divi` could lose content or structure in a few HTML shapes: HTML5 sections placed after a stylesheet link, `<meta>` or `<style>` (the page was refused as empty or the first section was dropped), content after the closing `</html>` tag, a section following loose text at the start of a fragment, a section following loose text after the closing `</body>` tag, a section, header, footer or other block right after a paragraph that was never closed, and a script whose code contains `</body>`, `</html>` or another closing tag (its code showed up as page text). In the last four a heading could turn into bold text. The word and link checks now see all of it.
* Improved: verified on Divi 5.15.1.

= 4.13.0 =
* New: ask your assistant to rebuild a page from a screenshot, the address of a page or its HTML. It writes a Divi 5 layout as a draft and the checker tests it before it is saved. Your assistant, not the plugin, looks at the picture or reads the page.
* New: 71 section patterns instead of 17, each one tested against the checker, with filters by role, layout and mood (`get_section_recipes`).
* New: ten design languages (editorial, glass dark, organic warm, tech mono, playful pastel, corporate trust, soft SaaS, bold vibrant, brutalist flat, luxe) with their colors, fonts, corners and spacing, so a whole page keeps one look.
* New: 40 style kits that set the exact look of buttons, cards, accordions, toggles, contact forms and image corners (`get_section_recipes` takes a `style_kit`; each kit has its own guide topic). Every combination was checked for readable text on the real Divi 5.15.1.
* New: guide topics for backgrounds, dividers, motion, hover states, layout, typography, imagery, controls, toggles, forms and composition. Each setting in them was rendered on a real Divi 5.15.1 page before it was taught.
* New: the AI Editor Dashboard asks once for a review, only after your assistant has saved at least 5 changes. Choose "Maybe later" (hidden for 30 days) or "Don't ask again". Nothing is sent anywhere.
* New: when a layout looks repetitive, or a recipe color or font token could not be resolved, the result carries a short hint (`advisories`). It never blocks a save.
* Improved: the MCP address answers a plain browser visit (GET) and DELETE with a normal "not allowed" reply instead of "not found". Hosts that ban an IP after many 404 errors no longer cut you off.
* Improved: the readme and the plugin's short description now say plainly that this is an MCP server for Divi 5.
* Improved: verified on Divi 5.15.1.

= 4.12.0 =
* New: works with Divi 5.15. Pages that use Divi 5.15 components (a section, row or module saved once and reused) and their Slots are now accepted, so your assistant can read and edit them instead of being refused. Verified by saving real builder-made components and rendering them in Divi 5.15.1. A Slot in a row or section, a row or another Slot inside a Slot, and a column saved as a component are still refused until they have been checked the same way.
* New: your assistant can see your site's components with `get_site_structure` (name, kind, Slot ids, how many pages use each; never their content) and is told when a change inside a component would not show, because Divi displays the component's own content on every page that uses it.
* New: your assistant is told when a save would remove more than half of a page's text, images or modules, so a rewrite from a partial copy is caught. It is a warning, not a refusal, and Undo is available.
* New: for a big page your assistant can read an outline or a single block instead of the whole layout (`get_page_layout` with `view`). On the real pages used for testing an outline is about a sixth of the size of the full layout.
* Improved: a refusal is much shorter. The first violation about a block keeps its list of allowed blocks, later ones point back to it, and at most 25 are listed. In testing, a refusal that lists 96 nesting mistakes dropped from about 36,000 tokens to about 2,000.
* Improved: a style value with an unclosed quote or bracket (for example `calc(10px`) is now refused. Divi writes it into the page's stylesheet as it is, and on Divi 5.15.1 it made every section lose its custom styling.
* Improved: verified on Divi 5.15.1 (converter, style shapes, global styles, page titles and undo all re-checked on it).

= 4.11.0 =
* New: your AI assistant can now change the title of an existing page or Divi Project. Ask it to rename a page and it changes only the WordPress title (what shows in the page list and, by default, the browser tab), or the title and the layout together. It can preview the change first, follows Approval mode, only touches pages you can edit, and never changes the page address (slug) or leaves the layout rewritten. A title change is not covered by Undo, so your assistant tells you the old title and can set it back with one more request.
* Improved: the style guide now explains that the page title and the big headline inside the layout are different things, so a request to "change the title" is no longer answered by editing only the headline.

= 4.10.0 =
* New: connect Claude on the web (claude.ai) with nothing to install. Turn on sign-in for Claude on the Settings screen, add the address it shows under Customize → Connectors in claude.ai, sign in to your own site and press Allow. Claude then works as you, with the permissions your account has, and every save is still checked and undoable. It is off until you turn it on, needs a public https address, and you can disconnect any app, or turn it off and remove everything, from the Settings screen.
* New: `html_to_divi` turns HTML you already have into a Divi 5 page: the structure, every word, every link and the images. It previews first and tells you what it could not convert (scripts, forms, embeds, site navigation and CSS are never converted); with one more step it saves a draft. Colors and fonts are not converted yet.
* New: a Test connection button on the Settings screen checks the address, the key and the permissions, and says in plain English what is wrong (for example a firewall blocking the REST API, plain permalinks, or a key owner who cannot edit pages).
* Improved: the style guide now teaches the per-device settings that were checked on a real Divi: a smaller headline on phones, text size and alignment per device, spacing per device, and columns that stack on a phone. The image guide teaches how to make images of different shapes the same size with Divi's own settings.
* Improved: the Settings screen explains that the ChatGPT route needs a paid ChatGPT plan, and mentions Laragon next to the other local tools. New FAQ answers cover plan usage, Divi AI, other AI plugins, Claude on the web and HTML conversion.
* Changed: 21 tools instead of 20 (`html_to_divi`).

= 4.9.0 =
* New: your AI assistant can now see your WooCommerce products. `list_products` lists and counts them with their prices, stock status and categories, and `get_product` reads one product in full, including its variations. Both are read-only: they never show downloadable files, purchase notes, customer or order data, or the text of a password-protected product, and they need the permission to edit products (shop managers and administrators have it). Available over MCP and the REST API, not in the ChatGPT Action.
* Improved: `get_site_structure` now also says how many items each content type has, so your assistant can answer "how many products (or pages, or posts) do I have?".

= 4.8.0 =
* New: your AI assistant can edit Divi Projects, not only pages. Every tool that reads, checks, saves, previews or undoes a page's layout now also works on a Divi Project, with the same checks, history and Approval mode. `list_divi_pages` takes an optional `post_type` (page or project) to list them. New pages are still always drafts, and posts and other content types are still refused.
* New: `get_custom_fields` lets your assistant read the custom fields of one page or Divi Project you can edit, with their values, so the copy it writes fits and it uses the right field names. It is read-only. Keys WordPress keeps private, and fields that look like passwords or tokens, are never shown, and long values are cut. Available over MCP and the REST API, not in the ChatGPT Action.
* Improved: `get_site_structure` now also lists the custom field names your posts use (names only, never values), and the style guide explains how to show a custom field in a module.
* Fixed: a page with an Email Optin (signup) module that has custom fields can now be edited by your AI assistant. Before, the check did not recognise those custom fields and refused to save any change to that page, even one far from the form.

= 4.7.0 =
* New: your AI assistant can now use your Divi number and text variables in the pages it builds (for example a padding or heading-size variable, or a shared line of text), the same way it already reuses your global colors. The style guide it reads explains exactly where this works, and `list_global_styles` points it there.
* New: when a layout uses a variable your site does not have, the check now tells your assistant (Divi would silently drop that value). This is advice only and never blocks a save.
* As before, the plugin only reads: variables, colors and presets are created in Divi itself.
* New: your AI assistant can show a custom field's value in a module, for example an Advanced Custom Fields name, photo or link, and the style guide it reads explains exactly where this works. When a layout uses a custom field your site does not have, the check now tells your assistant (Divi would show an empty module). This is advice only and never blocks a save.
* Improved: when Advanced Custom Fields is active, `get_site_structure` now also says where each field group applies (for example "post_type == page"), so your assistant only uses fields that exist on the page it is editing.
* Improved: the Settings screen now shows one line saying when your AI assistant last reached your site and what it did, or that no request has arrived yet, so you can tell at a glance whether the connection works.
* Improved: with Approval mode on, a preview now only counts while the page is still as it was when previewed. If the page changed in the meantime (for example you saved it in the Divi builder), your assistant has to preview again.
* Fixed: an assistant that sends the standard MCP notifications other than the first one (such as a cancellation) no longer gets an error back.

= 4.6.0 =
* New: your AI assistant can look up how your site is set up with `get_site_structure`: custom post types, taxonomies, image sizes and, when Advanced Custom Fields is active, its field groups and fields (names, labels, types and choices; never field values). Read-only.
* New: Approval mode (Settings screen, off by default). When it is on, your AI assistant must preview every edit to a page's content before it can save it.
* Improved: clearer setup on the Settings screen. Claude Desktop now gets the working setup (it connects through a small Node.js helper, so the screen says Node.js is needed and what to do if Mac or Windows reports a missing `npx`), Gemini CLI has its own tab, and there is a note on which assistants can reach a local site. The Features screen says that your global colors, variables and presets are read-only.
* Fixed: the connection check (`ping`) now answers exactly as the MCP specification asks, which strict clients require.
* New: FAQ entries on safety, token use, Gemini, local sites and the Mac connection error.

= 4.5.0 =
* Fixed: the "Recent AI edits" list on the dashboard now shows only pages you can restore. Edits to other kinds of layouts, such as a header or footer saved by an add-on, no longer appear there with a Restore button that cannot work.

= 4.4.0 =
* Safer: your AI assistant can no longer save custom CSS, JavaScript or PHP through a page layout. The checker refuses custom-CSS fields, Divi Code modules, script, style and iframe markup, javascript: links and event attributes, and says exactly where. Code already on a page, for example custom CSS you added in the Visual Builder, stays as it is.
* New: your AI assistant can look up your site's own Divi colors and presets, so the pages it builds can match your site. A new read-only tool, `list_global_styles`, lists them.
* New: when a page uses a color or preset your site does not have, the save and preview results now say so. The save still goes ahead, and Divi shows that part of the page with its default look.
* It cannot create or change presets or colors.

= 4.2.0 =
* New: preview before saving. `update_page_layout` and `edit_page_content` accept `dry_run`: they return the checker's verdict and a short list of the blocks and settings that would change, and save nothing.

= 4.1.0 =
* Undo history is now kept in its own table in your database instead of in each page's custom fields. Pages and the front end no longer load it, and copying or exporting a page no longer carries its history along.
* Existing undo history is moved over automatically. Nothing changes in how undo works or in what your AI assistant sees.
* Going back to version 4.0.0 afterwards is not supported: it would not find the moved history.
* Deleting a page still deletes its undo history.

= 4.0.0 =
* Renamed to JHMG AI Editor for Divi 5 (plugin folder and slug: `jhmg-ai-editor-for-divi-5`).
* `create_page` is part of this plugin: create new pages, always saved as drafts.
* New: `list_media_images` lets your AI reuse the images already in your Media Library (read-only).
* New: a built-in pack of 44 original images. Section patterns and guides now use it, so no images are loaded from other websites.
* Undo history (`list_page_history`, `get_page_history_entry`, `restore_page_version`) is part of this plugin.
* Removed every tool that changed site settings or saved CSS or PHP code, and all licensing code, from this plugin.
* The plugin makes no calls to external services and loads no remote files.
* Dashboard: one card about the separate add-on, which you can dismiss.

= 3.5.0 =
* Undo for AI edits: the previous version of a page is kept when the AI saves it, and can be restored by the AI or from the Dashboard.

= 3.4.0 =
* Support for 24 more Divi 5 modules, each verified to render on Divi 5.14.
* A notice when your Divi is newer than the newest version this plugin was verified on.

= 3.3.0 =
* Prepared for the WordPress.org directory. Verified on WordPress 7.1 and Divi 5.14.

= 3.2.0 =
* Surgical edits: change one piece of text without rebuilding the page (`edit_page_content`).

= 3.1.0 =
* A guided connection screen for Claude, Cursor, VS Code, Gemini, ChatGPT and other MCP clients.

= 2.0.0 to 3.0.0 =
* MCP server and REST API, OpenAPI spec for ChatGPT, the deterministic Divi 5 checker, the style, site, landing and image guides, the section pattern library and the admin screens.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 4.19.0 =
Adds Lab, a tab where you answer a few questions, see a preview and save a draft page, and the `lab_build` tool so your assistant can fill in its words. New and not yet confirmed with every assistant. Nothing changes unless you use it.

= 4.16.0 =
ChatGPT can now connect as a custom connector that signs in with your WordPress login, since OpenAI is retiring custom GPT Actions. Not yet tested by us with a ChatGPT account. Nothing changes unless you turn on the sign-in.

= 4.15.0 =
The checker now refuses layouts that would make Divi show a "500 error", headline type and section spacing follow the design language, and kits style more modules. In the default look some headlines are a little bolder.

= 4.14.0 =
Style kits now also style divider lines, rules, tag labels and icon badges, so a page keeps one look. In the default look a few lines are slightly heavier and icon badges squarer. Nothing changes unless your assistant uses them.

= 4.13.0 =
Your assistant can rebuild a page from a screenshot or a web page, and gets many more section patterns, ten design languages and 40 style kits to keep a page looking consistent. Nothing changes unless your assistant uses them.

= 4.7.0 =
Your AI assistant can reuse your Divi number and text variables and is warned about ones that do not exist. Nothing changes unless your assistant uses them.

= 4.6.0 =
Adds a read-only look-up of your site's post types, taxonomies, image sizes and ACF fields for your AI assistant, an optional Approval mode, and clearer setup instructions. Nothing changes unless your AI assistant uses it or you turn Approval mode on.

= 4.5.0 =
The dashboard's recent-edits list only shows pages you can restore. Nothing else changes.

= 4.4.0 =
Adds a read-only look-up of your site's Divi colors and presets for your AI assistant, and a note when a page uses one your site does not have. Nothing changes unless your AI assistant uses it.

= 4.2.0 =
Adds an optional preview (`dry_run`) to the two tools that save pages. Nothing changes unless your AI assistant uses it.

= 4.1.0 =
Undo history moves to its own database table. Your existing history is moved over automatically after the update; there is nothing to do.

= 4.0.0 =
New name and folder (`jhmg-ai-editor-for-divi-5`). Creating pages, undo and the new Media Library tool are included. Tools that changed site settings or saved CSS or PHP code are no longer part of this plugin.
